#include <cpprest/http_client.h>
#include <cpprest/filestream.h>
#include <cpprest/json.h>
#include <cpprest/uri.h>
#include <boost/algorithm/string/replace.hpp>
#include <sys/time.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/md5.h>

using namespace utility;                    // Common utilities like string conversions
using namespace web;                        // Common features like URIs.
using namespace web::http;                  // Common HTTP functionality
using namespace web::http::client;          // HTTP client features
using namespace concurrency::streams;       // Asynchronous streams
using namespace std;


class File{
public:
        string id;
        string password;
        void login_screen();
        int login(string id, string password);
        int login_status(json::value const & value);
        int upload();
        void json_post(json::value json_v);

        void my_print_results(json::value const & value);
        void http_status(int status_code);
};
void File::login_screen()
{
    cout<<"Please input your username and password\n";
    cin>>this->id>>this->password;
}

int File::login(string id,string password){
    int login_status;
    json::value post_login;
    post_login["id"] = json::value::string(id);
    post_login["password"] = json::value::string(password);

    http_client client(U("http://114.116.138.139:8000/"));
    uri_builder builder(U("api/device/"));
    client
    // send the HTTP GET request asynchronous
    .request(methods::POST,builder.to_string(),post_login)
    // continue when the response is available
    .then([&](http_response response) -> pplx::task<json::value> {
        // if the status is OK extract the body of the response into a JSON value
        // works only when the content type is application\json
        cout<<"post.request: "<<response.status_code()<<endl;
        if(response.status_code() == status_codes::OK) { //Created?
            cout<<"ok!!!\n";
            response.headers().set_content_type("application/json"); //fixed June 22th
            return response.extract_json();
        }
        // return an empty JSON value
        return pplx::task_from_result(json::value());
    })
    .then([&](pplx::task<json::value> previousTask) {
        try
        {
            cout<<"connect to client"<<endl;
            json::value jv = previousTask.get();
            login_status= this->login_status(jv);;  //my print result parameter
        }
        catch (const std::exception& e)
        {
        cout<<"error!\n";
            cout << e.what() << endl;
        }
    })
    .wait();

    return login_status;
}

int File::login_status(json::value const & value){
    cout<<"--------------------login  status--------------------"<<endl;
    if(value.size()){
        //auto obj =value.as_object();
        auto code = value.at(U("code")).as_integer();
        auto reason = value.at(U("reason")).as_string();
        auto state = value.at(U("state")).as_string();
        cout << "code = " << code <<endl
        << "reason = " << reason <<endl
        << "state = " << state << endl;
        return code;
      }
    cout<<"--------------------------End--------------------------"<<endl;

}


int File::upload()
{
     // Open stream to file.

    cout<<"Upload:"<<endl;
  
    file_stream<unsigned char>::open_istream("wallpaper.txt")
    .then([&](concurrency::streams::basic_istream<unsigned char> fileStream)
    { 
        http_client client(U("http://114.116.138.139:8000/api/device/"));
        // Make HTTP request with the file stream as the body.
        client.
        request(methods::POST,"wallpaper",fileStream)
        .then([fileStream](http_response response)
        {
            fileStream.close();
            // Perform actions here to inspect the HTTP response…
            cout<<"post file status: "<<response.status_code()<<endl;
            if(response.status_code() == status_codes::OK){
            }
            });
    });  
    return 1;
}

int main(){
        File client;
        int status = 0;
        client.id="00001";
        client.password="123456";
        client.login(client.id,client.password);
        client.upload();
        
}